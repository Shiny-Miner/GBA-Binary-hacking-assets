TM Menu Party Icons

This patch is to be used with Fire Red only.

Offsets used: C05770 - C05D77

If used, please credit LibertyTwins, Shiny Miner, Compumaxx and ansh860.

---

If you'd prefer to do the C: injection, to locate the data at whatever offset you wish, please see the links below: (Note: this is very compilcated unless you're familiar with Environment Variables, Path and Command Prompt)

"Tha Code Mining Hub" Discord: https://discord.gg/2vRGgnqw7T

TM Case Icons repo: https://github.com/Shiny-Miner/Porting-template/tree/TM-case-icons

Pre-requirements: https://www.mediafire.com/file/bdq6eept3e00bb8/pret-tools.rar/file

ARMIPS: https://github.com/Kingcom/armips/releases

devkitPro: https://github.com/devkitPro/installer/releases

Python: https://www.python.org/downloads/