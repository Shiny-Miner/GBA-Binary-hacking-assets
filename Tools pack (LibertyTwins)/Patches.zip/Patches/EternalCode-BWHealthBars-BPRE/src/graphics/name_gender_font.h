
//{{BLOCK(name_gender_font3)

//======================================================================
//
//	name_gender_font3, 152x32@4, 
//	+ palette 16 entries, not compressed
//	+ 76 tiles not compressed
//	Total size: 32 + 2432 = 2464
//
//	Time-stamp: 2022-02-05, 22:20:46
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.6
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_NAME_GENDER_FONT3_H
#define GRIT_NAME_GENDER_FONT3_H

#define name_gender_font3TilesLen 2432
extern const unsigned char name_gender_font3Tiles[2432];

#define name_gender_font3PalLen 32
extern const unsigned char name_gender_font3Pal[32];

#endif // GRIT_NAME_GENDER_FONT3_H

//}}BLOCK(name_gender_font3)
