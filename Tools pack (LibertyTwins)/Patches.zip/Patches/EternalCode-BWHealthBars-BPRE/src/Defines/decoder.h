#ifndef DECODER_H
#define DECODER_H

char string_buffer[1000];
char buffer1[16];
char buffer2[32];
char buffer3[20];
char buffer4[20];

char *str_cpy(char *, char *);
char *fmt_int_10(char *, char *, u8, u8);


#endif /* DECODER_H */
