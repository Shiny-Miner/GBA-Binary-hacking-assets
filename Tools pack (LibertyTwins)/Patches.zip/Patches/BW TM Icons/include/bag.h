#ifndef GUARD_BAG_H
#define GUARD_BAG_H

void SetBagCallback(void *);
void ReturnFromItemToBag(u8);

#endif // GUARD_BAG_H