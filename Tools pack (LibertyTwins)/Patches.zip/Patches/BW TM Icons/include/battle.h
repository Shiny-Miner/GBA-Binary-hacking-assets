#ifndef GUARD_BATTLE_H
#define GUARD_BATTLE_H

extern const u8 *gBattlescriptCurrInstr;

#endif // GUARD_BATTLE_H