#ifndef GUARD_ALLOC_H
#define GUARD_ALLOC_H

void *Alloc(u32 size);
void Free(void *pointer);

#endif // GUARD_ALLOC_H