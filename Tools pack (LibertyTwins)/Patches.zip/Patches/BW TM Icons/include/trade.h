#ifndef GUARD_TRADE_H
#define GUARD_TRADE_H

void SetTradedMonPokedexFlags(u8 partyIdx);

#endif // GUARD_TRADE_H