#ifndef GUARD_INTERNATIONAL_STRING_UTIL_H
#define GUARD_INTERNATIONAL_STRING_UTIL_H

#include "menu.h"

int GetStringCenterAlignXOffset(int fontId, const u8 *str, int totalWidth);

#endif // GUARD_INTERNATIONAL_STRING_UTIL_H