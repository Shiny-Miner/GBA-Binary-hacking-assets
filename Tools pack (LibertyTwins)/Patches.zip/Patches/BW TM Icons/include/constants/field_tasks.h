#ifndef GUARD_CONSTANTS_FIELD_TASKS_H
#define GUARD_CONSTANTS_FIELD_TASKS_H

#define STEP_CB_DUMMY               0
#define STEP_CB_ASH                 1 // Unused
#define STEP_CB_FORTREE_BRIDGE      2 // Unused, dummied
#define STEP_CB_PACIFIDLOG_BRIDGE   3 // Unused, dummied
#define STEP_CB_ICE                 4
#define STEP_CB_TRUCK               5 // Unused, dummied
#define STEP_CB_SECRET_BASE         6 // Unused, dummied
#define STEP_CB_CRACKED_FLOOR       7 // Unused

#endif // GUARD_CONSTANTS_FIELD_TASKS_H
