
//{{BLOCK(TMCaseBG)

//======================================================================
//
//	TMCaseBG, 256x256@4, 
//	+ palette 20 entries, lz77 compressed
//	Total size: 40 = 40
//
//	Time-stamp: 2024-08-03, 19:49:36
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.6
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_TMCASEBG_H
#define GRIT_TMCASEBG_H

#define TMCaseBGPalLen 40
extern const unsigned int TMCaseBGPal[10];

#endif // GRIT_TMCASEBG_H

//}}BLOCK(TMCaseBG)
