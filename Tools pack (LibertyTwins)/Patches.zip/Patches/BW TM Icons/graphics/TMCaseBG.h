
//{{BLOCK(TMCaseBG)

//======================================================================
//
//	TMCaseBG, 256x256@4, 
//	+ 34 tiles (t|f|p reduced) lz77 compressed
//	+ regular map (flat), lz77 compressed, 32x32 
//	Total size: 316 + 328 = 644
//
//	Time-stamp: 2024-08-03, 19:49:36
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.6
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_TMCASEBG_H
#define GRIT_TMCASEBG_H

#define TMCaseBGTilesLen 316
extern const unsigned int TMCaseBGTiles[79];

#define TMCaseBGMapLen 328
extern const unsigned int TMCaseBGMap[82];

#endif // GRIT_TMCASEBG_H

//}}BLOCK(TMCaseBG)
