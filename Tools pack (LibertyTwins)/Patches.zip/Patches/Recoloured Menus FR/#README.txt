Thanks for using our patch! Be sure to see linktr.ee/libertytwins to see our other releases.

User Information:

The Recoloured Menus patch uses no free space as it changes existing palettes.

If you apply the Recoloured HGSS Party Screen patch, it uses these offsets:
11FFF4 - 11FFA9
120008 - 1232C7
459EC5 - 45A4EC
E82702 - E82E52

Upon using any of these patches, please credit LibertyTwins
If you use the HGSS Party Screen patch, please credit Lunos as well