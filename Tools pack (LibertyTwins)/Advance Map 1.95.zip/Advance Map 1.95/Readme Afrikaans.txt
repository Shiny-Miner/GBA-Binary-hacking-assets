﻿********************************************
*** Advance Map Ver 1.95 - Afrikaans     ***
********************************************

Die program is vir die reditering van Landkaart-, bewegingspermissies, teël-, gebeurtenis-, en wildspokemondata.
'n Blokredakteur is ook beskikbaar
Die Program werk met die alle versies van Pokémon Advance, in alle tale.


.:|BELANGRIK|:.
-^-^-^-^-^-^-
Die program is deur LU-HO Poké geprogrameer, en dus, hou hy ook die kopiereg vir dit.
As jy die program op 'n ander webtuiste afgelaai het, behalwe die http://amneu.no-ip.info, www.LU-HO.ch.vu, ampage.no-ip.info, romresources.net,
laat weet my so gou moontilk, assebleif. My e-pos is: luhopoke@gmail.com


********************************
***          Groete          ***
********************************
'n Groot dankie aan:
Jigglypuff vir die bron van Goldmap2 Beta
en Jay, wie dit vir my gegee het.

Verdere Groete aan:
Tauwasser en F-Zero vir hulle tutorials.
Mikaron vir sy werk.
Serwe, wie vir my 'n paar idees gegee het.
Mulle, wie vir my 'n fout wat ek begaan het aangewys.
Scizz, Timhay, GruntZ, Ashly138, Usohachi, BlueSonic, Sylph, Liquid_Thunder, IIIMQIII, Netto-kun vir die vertaling van die INI's.
en laaste, aan Filb vir sy bord.
Nog 'n dankie aan F-Zero wie vir my met die sprietpalette gehelp het.
Dark01 vir sy hulp met die spriete.
Dankie ook aan evilboy vir sy hulp by die FAQs.
En ook weer aan Scizz, dark01, BlueSonic and F-Zero vir die "Betatests".
Aruka and perappu music list extension.
A big thanks goes to Mastermind_X for the structure of the Word Map data and for helping me make use of it.
A big thanks to Tutti for his great beta testing and extension of the behaviour data.
Tauwasser, Scizz, Satry, Ashly138, Anthony, wakachamo, HackMew, Christos, Martin², Sebbe17/Jungleman, 44tim44 for the new translations of the INIs.
The Lazarus Development Team, for this genial OpenSource Development Environment.
Kiyron for extentions on FR/LG Music liste.
prime for his SeasonSystem.
Dragonflye, Aeonos, haefele, prime, Tutti, skyfall, pokemontutorialTV for the Beta tests on AM 1.95.
