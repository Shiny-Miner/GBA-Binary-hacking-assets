﻿********************************************
*** Advance Map Ver 1.95 - Polish        ***
********************************************

Ten program służy do edycji map, zezwoleń ruchu, danych klocków, event'ów i danych dzikich pokemon'ów.
Później do edycji powinny być dostępne też dane kolizji.
Działa on z ROM'ami Pokemon Ruby and Sapphire, in all language.


.:|WAŻNE|:.
-^-^-^-^-^-^-
Ten program został stworzony przez LU-HO Poké i w rezultacie prawa autorskie należą do LU-HO Poké!
Jeżeli pobrałeś ten plik z innej strony niż http://amneu.no-ip.info, www.LU-HO.ch.vu, ampage.no-ip.info, romresources.net,
proszę napisz mi o tym szybko! Mój mail to: luhopoke@gmail.com


***************************
***    Podziękowania    ***
***************************
Wielkie podziękowania idą do:
Jigglypuff for the Source of Goldmap2 Beta
and Jay, who gave it to me.

Dalsze podziękowania wędrują do:
Tauwasser and F-Zero for their tutorials.
Mikaron for his work.
Serwe for giving me a few ideas.
Mulle who pointed me to a mistake.
Scizz, Timhay, GruntZ, Ashly138, Usohachi, BlueSonic, Sylph, Liquid_Thunder, IIIMQIII, Netto-kun for the translations of the inis.
And of course, Filb for his board.
Another tahnk you goes out to F-Zero who helped me with the Sprite-Pallets.
Also dark01 received a big thank you for his help with the Sprites.
Thanks to evilboy for his help at the FAQs.
Another thanks goes to Scizz, dark01, BlueSonic and F-Zero for the Betatests.
Aruka and perappu music list extension.
A big thanks goes to Mastermind_X for the structure of the Word Map data and for helping me make use of it.
A big thanks to Tutti for his great beta testing and extension of the behaviour data.
Tauwasser, Scizz, Satry, Ashly138, Anthony, wakachamo, HackMew, Christos, Martin², Sebbe17/Jungleman, 44tim44 for the new translations of the INIs.
The Lazarus Development Team, for this genial OpenSource Development Environment.
Kiyron for extentions on FR/LG Music liste.
prime for his SeasonSystem.
Dragonflye, Aeonos, haefele, prime, Tutti, skyfall, pokemontutorialTV for the Beta tests on AM 1.95.
