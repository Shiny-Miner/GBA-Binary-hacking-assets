Here is a collection of ASM routines inserted to the rom.
Neither DPE nor CFRU inserts this, yet these were recommended Add-ons.

Game Freak Presents Fix routine can be found here:
https://www.pokecommunity.com/showthread.php?t=306230


Gendered Text Color routine can be found here:
https://www.pokecommunity.com/showpost.php?p=6350611&postcount=6

