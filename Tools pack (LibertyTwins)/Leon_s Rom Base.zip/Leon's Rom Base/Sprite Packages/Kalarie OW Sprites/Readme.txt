Here is a bunch of Overworld sprites taken from Kalarie's resource.
This isn't even all of them either. 
They are in order as they were inserted in this Rom Base.

Link to the original post:

https://www.pokecommunity.com/showthread.php?t=407124

Refer to the Notes for more information on these sprites.
If you used the version where the sprites are not inserted, feel free to use these at your leisure.