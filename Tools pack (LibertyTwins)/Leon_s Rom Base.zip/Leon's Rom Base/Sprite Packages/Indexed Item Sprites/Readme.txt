Here is a resource of indexed item sprites.
These were already inserted into the ROM, so it serves no actual purpose for the base itself.

Many of these were taken from thedarkdragon11's post found here:
https://www.pokecommunity.com/showthread.php?t=365303

The majority of images however were made by me (Leon).

Figured that I should throw these in, Wynaut?
Enjoy!