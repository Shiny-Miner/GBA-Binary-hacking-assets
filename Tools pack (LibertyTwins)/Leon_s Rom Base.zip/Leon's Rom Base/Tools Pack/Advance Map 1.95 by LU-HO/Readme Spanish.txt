﻿********************************************
*** Advance Map Ver 1.95 - Español       ***
********************************************

Este programa sirve para editar Mapas, movimientos permitidos, data de los bloques, eventos y los pokémons salvajes.
It is compatible with all version of Pokémon Advance in all languages.


.:|IMPORTANTE|:.
-^-^-^-^-^-^-^-^
Este programa fue hecho por LU-HO Poké y esta registrado por LU-HO Poké!
Si descargaste el programa de una web que no es http://amneu.no-ip.info, www.LU-HO.ch.vu, ampage.no-ip.info, romresources.net
reportamelo por favor a mi mail! Mi mail es: luhopoke@gmail.com


********************************
***     Agradecimientos      ***
********************************
Gran agradecimiento para:
Jigglypuff por la fuente de Goldmap2 Beta
y a Jay, que fue el que me la dio.

Otros agradecimientos a:
Tauwasser y F-Zero por sus guias.
Mikaron por su trabajo.
Serwe por darme ideas.
Mulle el cual me marco un error.
Scizz, Timhay, GruntZ, Ashly138, Usohachi, BlueSonic, Sylph, Liquid_Thunder, IIIMQIII, Netto-kun por la traduccion de los inis.
También, a Filb por su foro.
Otra a F-Zero que me ayudo con las Paletas de los Sprites.
A dark01 que también me ayudo con los Sprites.
Gracias a evilboy  por su ayuda con los FAQs.
Y por ultimo a Scizz, dark01, BlueSonic y F-Zero por los Betatests.
Aruka and perappu music list extension.
A big thanks goes to Mastermind_X for the structure of the Word Map data and for helping me make use of it.
A big thanks to Tutti for his great beta testing and extension of the behaviour data.
Tauwasser, Scizz, Satry, Ashly138, Anthony, wakachamo, HackMew, Christos, Martin², Sebbe17/Jungleman, 44tim44 for the new translations of the INIs.
The Lazarus Development Team, for this genial OpenSource Development Environment.
Kiyron for extentions on FR/LG Music liste.
prime for his SeasonSystem.
Dragonflye, Aeonos, haefele, prime, Tutti, skyfall, pokemontutorialTV for the Beta tests on AM 1.95.
