﻿
————————————————————————调整窗口宽度至此行完整显示来取得最佳阅读效果———————————————————————

********************************************
*** Advance Map Ver 1.95 - 中文版        ***
********************************************

此程序是用来编辑地图、运动许可、地图块数据、事件以及野生精灵数据的。
内置地图块编辑器。
此版本同所有版本所有语言的口袋妖怪游戏兼容。


··|重要|··
—^—^—^—^—^—
此程序由LU-HO Poke编写，因此版权属于LU-HO Poke。
如果你从另一个地方而不是从 http://amneu.no-ip.info, www.LU-HO.ch.vu, ampage.no-ip.info, romresources.net 下载得到，请立刻告知我！！电子邮件：luhopoke@gmail.com


********************************
***          致  敬          ***
********************************
让我们把最崇高的敬意致以：
Jigglypuff，为了Goldmap2 Beta的资源
以及Jay，他把它给了我。

我们还要向一下各位致敬：
Tauwasser和F-Zero，因为他们的教程。
Mikaron，因为他的工作。
Serwe，因为他给了我一些主意。
Mulle，向我指出了一个错误。
Scizz，Timhay，GruntZ，Ashly138，Usohachi，BlueSonic，Sylph，Liquid_Thunder，IIIMQIII，Netto-kun，因为他们翻译了ini文件。
当然还有，Filb for his board.
我们还要感谢F-Zero，它给了我人物画板上的帮助。
当然dark01也落不下，他给了我人物上的帮助。
感谢每一个在FAQ上的帮助。感谢！
还要感谢Scizz，dark01，BlueSonic和F-Zero，他们帮我进行了测试。
Aruka和perappu音乐列表的提取。
还要热烈感谢Mastermind_X，他提供了大地图结构数据并且帮助我用上了这些数据。
热烈感谢Tutti，他进行了大量的测试，还有提供动作数据。
Tauwasser，Scizz，Satry，Ashly138，Anthony，wakachamo，HackMew，Christos，Martin? Sebbe17/Jungleman，44tim44，对ini进行了新的翻译。
Kiyron for extentions on FR/LG Music liste.
prime for his SeasonSystem.
Dragonflye, Aeonos, haefele, prime, Tutti, skyfall, pokemontutorialTV for the Beta tests on AM 1.95.
