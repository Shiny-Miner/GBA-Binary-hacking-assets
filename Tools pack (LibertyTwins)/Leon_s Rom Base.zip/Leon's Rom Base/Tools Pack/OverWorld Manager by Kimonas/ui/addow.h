#ifndef ADDOW_H
#define ADDOW_H


class addOW
{
public:
    addOW();
};

#endif // ADDOW_H