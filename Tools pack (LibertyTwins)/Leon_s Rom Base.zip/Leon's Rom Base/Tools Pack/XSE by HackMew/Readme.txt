
				Free Space Finder (aka FSF) v1.0.2

       		    Copyrigth � 2007 Andrea Sartori aka Mew2 aka HackMew

 ===========================================================================================
					-DESCRIPTION-
 ===========================================================================================

			Searches for some free space inside a ROM.

 ===========================================================================================
				       -INSTRUCTIONS-
 ===========================================================================================

 1) Open your favourite ROM.
 2) Change the Seaching Options as you like. Each one is self-explanitory.
 3) Click the Search button. If the program find some free space, in the list it will
    be added the corresponding offset.
 
Have fun ;)
				
