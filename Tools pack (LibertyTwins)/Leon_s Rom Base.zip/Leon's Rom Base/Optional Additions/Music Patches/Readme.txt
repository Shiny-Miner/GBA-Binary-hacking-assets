Note that you will have to configure the included music files in CFRU if you apply these.
The configurations in question are these files:

Include/Constants/songs.h
Src/Tables/music_tables.c

Additionally, anything you want like class based trainer battle music will be based upon those changes.
See the Ultimate Rom Hack Planner To Do List Tab for more details!

The same must be done if you decide to hack and add your own music into the rom instead of using these patches!
Read the CFRU documentation provided by Skeli for help!

