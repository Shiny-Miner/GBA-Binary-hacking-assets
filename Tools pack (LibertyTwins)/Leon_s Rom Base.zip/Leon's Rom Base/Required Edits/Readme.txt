Contained within this folder are required edits you must make to DPE and CFRU.
This is to ensure that you are able to utilize the rom base to its fullest potential.
These edits to the various files are REQUIRED for compatibility.
Detailed instructions are contained within.

NOTE: Do not replace the files in the DPE or CFRU directories! They are not 1-1 replacements!
      The text files contain instructions of what to change!

Here is a quick list as a reference:

DPE:

*DPE Master/Scripts/Make.py
*DPE Master/Include/Evolution.h
*DPE Master/Include/Items.h
*DPE Master/Src/Evolution_Table.c
*DPE Master/Src/Updated_code.c

CFRU:

*CFRU Master/Scripts/make.py
*CFRU Master/asm_defines.s
*CFRU Master/bytereplacement
*CFRU Master/routinepointers
*CFRU Master/special_inserts.asm
*CFRU Master/Assembly/Data/item_tables.s
*CFRU Master/Include/Constants/battle.h
*CFRU Master/Include/Constants/Items.h
*CFRU Master/Include/Constants/songs.h
*CFRU Master/Src/Character_customization.c
*CFRU Master/Src/config.h
*CFRU Master/Src/dynamax.c
*CFRU Master/Src/Tables/Item_Tables.c
*CFRU Master/Strings/ability_name_table.string

Additionally, there are folders called Optional Changes- these are instructions in the event you want to edit something.
Do not ask me to elaborate on those further, consult the CFRU documentation or ask in Skeli's Discord server.

Note: Check the Rom Hack Planner for a more in depth list for the optional edits!