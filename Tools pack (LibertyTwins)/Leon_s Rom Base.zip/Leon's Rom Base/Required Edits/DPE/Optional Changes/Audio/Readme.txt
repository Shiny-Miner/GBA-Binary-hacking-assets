The following information is taken from the DPE Master/Include/cry_data.h tutorial file:

---------------------
Adding New Entries
---------------------
Part A: If you added new cries, you must place the sound files in the Audio folder.
When added to the Audio folder they must be organized as such.

gCryX.wav	Where X= Pokemon name (again no need to capitalize)

(like this: gCryTurtwig.wav)

Part B: Afterwards, you must create a text file with a name that matches it, like so:

gCryX_flags.txt

(like this: gCryTurtwig_flags.txt)

Part C: This file only needs to contain the following text:
-c

That's it. You're done. Do this for every new entry you create.

Make sure you define the new cries in Include/cry_data.h, Src/Cry_Table.c and Src/Cry_Table_2.c